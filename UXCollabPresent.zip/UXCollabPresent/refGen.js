// JavaScript source code
window.onload = function () {
    var bookingReference = Math.floor((Math.random() * 10000) + 1000);


    document.getElementById('output').innerHTML = bookingReference;
};